<?php
session_start();

// === CARGAR CONFIGURACIÓN DE GITHUB ===
$config_file = 'config/github_config.json';
if (!file_exists($config_file)) {
    die("<div style='color:#ef4444; background:#000; padding:30px; font-family:Arial; text-align:center;'>
         <h2>Error: No se encontró config/github_config.json</h2></div>");
}

$github_config = json_decode(file_get_contents($config_file), true);
if (!$github_config || empty($github_config['token']) || empty($github_config['repo_owner']) || empty($github_config['repo_name'])) {
    die("<div style='color:#ef4444; background:#000; padding:30px; font-family:Arial; text-align:center;'>
         <h2>Error: Configuración de GitHub incompleta</h2></div>");
}

$data_file = $github_config['data_file'] ?? 'home.json';
$branch = $github_config['branch'] ?? 'main';

// === FUNCIONES ===
function getHomeJson($github_config) {
    $url = "https://api.github.com/repos/{$github_config['repo_owner']}/{$github_config['repo_name']}/contents/{$github_config['data_file']}?ref={$github_config['branch']}";
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        "Authorization: Bearer {$github_config['token']}",
        "User-Agent: Admin-Home-Tool",
        "Accept: application/vnd.github.v3+json"
    ]);
    $response = curl_exec($ch);
    $httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($httpcode !== 200) return ['error' => "Error HTTP $httpcode"];
    $data = json_decode($response, true);
    $content = base64_decode($data['content']);
    $json = json_decode($content, true);
    return isset($json['data']) ? ['data' => $json['data'], 'sha' => $data['sha']] : ['error' => 'Formato inválido'];
}

function saveHomeJson($new_data, $sha, $github_config) {
    $content = base64_encode(json_encode(['data' => $new_data], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    $url = "https://api.github.com/repos/{$github_config['repo_owner']}/{$github_config['repo_name']}/contents/{$github_config['data_file']}";

    $payload = [
        'message' => 'Admin: Reparar duplicados y reindexar home.json',
        'content' => $content,
        'sha' => $sha,
        'branch' => $github_config['branch']
    ];

    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "PUT");
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        "Authorization: Bearer {$github_config['token']}",
        "User-Agent: Admin-Home-Tool",
        "Accept: application/vnd.github.v3+json"
    ]);
    $response = curl_exec($ch);
    $httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    return $httpcode === 200 || $httpcode === 201;
}

// === REPARAR ===
$message = $message_type = '';
if (isset($_POST['accion']) && $_POST['accion'] === 'reparar') {
    $home = getHomeJson($github_config);
    if (isset($home['error'])) {
        $message = $home['error'];
        $message_type = 'danger';
    } else {
        $items = $home['data'];
        $unique = [];
        $seen = [];

        foreach ($items as $item) {
            $id = $item['id_tmdb'] ?? null;
            if (!$id) continue;

            if (!isset($seen[$id])) {
                $seen[$id] = $item;
                $unique[] = $item;
            } else {
                $old_time = strtotime($seen[$id]['updated_at'] ?? '0');
                $new_time = strtotime($item['updated_at'] ?? '0');
                if ($new_time > $old_time) {
                    $seen[$id] = $item;
                    foreach ($unique as &$u) {
                        if (($u['id_tmdb'] ?? null) == $id) $u = $item;
                    }
                }
            }
        }

        $reindexed = [];
        foreach ($unique as $i => $item) {
            $reindexed[(string)$i] = $item;
        }

        $eliminados = count($items) - count($reindexed);
        if ($eliminados > 0 || count(array_filter(array_keys($items), 'is_numeric')) !== count($items)) {
            $saved = saveHomeJson($reindexed, $home['sha'], $github_config);
            $message = $saved 
                ? "¡Éxito! Se eliminaron $eliminados duplicados y se reindexó todo correctamente."
                : "Error al guardar en GitHub.";
            $message_type = $saved ? 'success' : 'danger';
        } else {
            $message = "¡Perfecto! No hay duplicados ni problemas de índice.";
            $message_type = 'success';
        }
    }
}

// Cargar datos actuales
$home_data = getHomeJson($github_config);
$items = $home_data['data'] ?? [];
$total = count($items);
$duplicados = 0;
$id_count = [];
foreach ($items as $item) {
    $id = $item['id_tmdb'] ?? 'null';
    $id_count[$id] = ($id_count[$id] ?? 0) + 1;
}
foreach ($id_count as $c) if ($c > 1) $duplicados += $c - 1;
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Home.json - Reparar Duplicados</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome 6 -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    
    <style>
        :root {
            --bg: #0f172a;
            --card: #1e293b;
            --border: #334155;
            --text: #e2e8f0;
            --primary: #3b82f6;
            --success: #10b981;
            --warning: #f59e0b;
            --danger: #ef4444;
            --info: #06b6d4;
        }
        body {
            background: var(--bg);
            color: var(--text);
            font-family: 'Inter', sans-serif;
            min-height: 100vh;
            margin: 0;
        }
        .navbar {
            background: #1e293b;
            padding: 1rem 0;
            box-shadow: 0 4px 12px rgba(0,0,0,0.3);
        }
        .card {
            background: var(--card);
            border: 1px solid var(--border);
            border-radius: 16px;
            overflow: hidden;
            transition: all 0.3s;
        }
        .card:hover { transform: translateY(-4px); box-shadow: 0 20px 40px rgba(0,0,0,0.4); }
        .card-header {
            background: rgba(59, 130, 246, 0.15);
            border-bottom: 1px solid var(--border);
            padding: 1.2rem 1.5rem;
        }
        .stat-card {
            text-align: center;
            padding: 1.5rem;
            border-radius: 12px;
            background: var(--card);
        }
        .stat-number {
            font-size: 2.5rem;
            font-weight: 700;
            margin: 10px 0;
        }
        .btn {
            border-radius: 12px;
            padding: 12px 28px;
            font-weight: 600;
            transition: all 0.3s;
        }
        .btn:hover { transform: translateY(-2px); }
        .btn-success { background: var(--success); border: none; }
        .btn-primary { background: var(--primary); border: none; }
        .btn-warning { background: var(--warning); border: none; }
        .table {
            margin: 0;
            font-size: 0.95rem;
        }
        .table th {
            border-top: none;
            font-weight: 600;
            color: #94a3b8;
        }
        .badge {
            font-size: 0.85rem;
            padding: 6px 10px;
            border-radius: 8px;
        }
        .duplicate-row {
            background: rgba(239, 68, 68, 0.25) !important;
            animation: pulse 2s infinite;
        }
        @keyframes pulse {
            0% { background: rgba(239, 68, 68, 0.25); }
            50% { background: rgba(239, 68, 68, 0.4); }
            100% { background: rgba(239, 68, 68, 0.25); }
        }
        .scroll-top {
            position: fixed;
            bottom: 25px;
            right: 25px;
            width: 50px;
            height: 50px;
            background: var(--primary);
            color: white;
            border: none;
            border-radius: 50%;
            font-size: 1.5rem;
            box-shadow: 0 8px 20px rgba(0,0,0,0.4);
            cursor: pointer;
            z-index: 999;
            opacity: 0;
            transition: all 0.3s;
        }
        .scroll-top.show { opacity: 1; }
    </style>
</head>
<body>

    <!-- Navbar -->
    <nav class="navbar">
        <div class="container-fluid px-4">
            <h3 class="mb-0 text-white">
                <i class="fas fa-cogs text-primary"></i> Admin Home.json
            </h3>
            <a href="panel.php" class="btn btn-outline-light">
                <i class="fas fa-arrow-left"></i> Volver al Panel
            </a>
        </div>
    </nav>

    <div class="container-fluid px-4 py-5">
        
        <?php if ($message): ?>
        <div class="alert alert-<?= $message_type ?> alert-dismissible fade show rounded-4 shadow-lg border-0">
            <i class="fas fa-<?= $message_type === 'success' ? 'check-circle' : 'exclamation-triangle' ?>"></i>
            <strong><?= $message_type === 'success' ? 'Éxito' : 'Error' ?>:</strong> <?= htmlspecialchars($message) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php endif; ?>

        <!-- Estadísticas -->
        <div class="row g-4 mb-5">
            <div class="col-md-3">
                <div class="stat-card border-primary border-start border-4">
                    <i class="fas fa-list-ul fa-3x text-primary mb-3"></i>
                    <div class="stat-number text-primary"><?= $total ?></div>
                    <small>Total de entradas</small>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stat-card <?= $duplicados > 0 ? 'border-danger border-start border-4' : '' ?>">
                    <i class="fas fa-clone fa-3x <?= $duplicados > 0 ? 'text-danger' : 'text-success' ?> mb-3"></i>
                    <div class="stat-number <?= $duplicados > 0 ? 'text-danger' : 'text-success' ?>"><?= $duplicados ?></div>
                    <small>Duplicados detectados</small>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stat-card border-success border-start border-4">
                    <i class="fas fa-fingerprint fa-3x text-success mb-3"></i>
                    <div class="stat-number text-success"><?= count(array_keys($id_count)) - ($id_count['null']??0) ?></div>
                    <small>IDs únicos</small>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stat-card border-info border-start border-4">
                    <i class="fab fa-github fa-3x text-info mb-3"></i>
                    <div class="stat-number text-info">OK</div>
                    <small>GitHub conectado</small>
                </div>
            </div>
        </div>

        <!-- Tabla principal -->
        <div class="card shadow-lg">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h4 class="mb-0">
                    <i class="fas fa-database"></i> Contenido de home.json
                </h4>
                <form method="POST" class="d-inline">
                    <button type="submit" name="accion" value="reparar" class="btn btn-success btn-lg shadow">
                        <i class="fas fa-magic"></i> Reparar Duplicados e Índices
                    </button>
                </form>
            </div>
            <div class="card-body p-0">
                <?php if ($duplicados > 0): ?>
                <div class="alert alert-danger m-3 rounded-4 border-0">
                    <i class="fas fa-exclamation-circle"></i>
                    <strong>¡Atención!</strong> Se encontraron <?= $duplicados ?> entradas duplicadas por <code>id_tmdb</code>.
                    Haz clic en el botón verde para eliminarlas automáticamente (se mantiene la versión más reciente).
                </div>
                <?php else: ?>
                <div class="alert alert-success m-3 rounded-4 border-0">
                    <i class="fas fa-check-circle"></i> ¡Excelente! No hay duplicados. Tu home.json está limpio.
                </div>
                <?php endif; ?>

                <div class="table-responsive">
                    <table class="table table-dark table-hover mb-0">
                        <thead class="text-uppercase small">
                            <tr>
                                <th><i class="fas fa-hashtag"></i> #</th>
                                <th><i class="fas fa-id-badge"></i> ID TMDB</th>
                                <th><i class="fas fa-film"></i> Título</th>
                                <th><i class="fas fa-tag"></i> Tipo</th>
                                <th><i class="fas fa-calendar"></i> Año</th>
                                <th><i class="fas fa-clock"></i> Actualizado</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $i = 0; foreach ($items as $item): 
                                $id = $item['id_tmdb'] ?? '—';
                                $is_dup = isset($id_count[$id]) && $id_count[$id] > 1 && $id !== 'null';
                            ?>
                            <tr <?= $is_dup ? 'class="duplicate-row"' : '' ?>>
                                <td><strong><?= $i++ ?></strong></td>
                                <td>
                                    <span class="badge <?= $is_dup ? 'bg-danger' : 'bg-primary' ?>">
                                        <?= htmlspecialchars($id) ?>
                                        <?= $is_dup ? " ($id_count[$id])" : "" ?>
                                    </span>
                                </td>
                                <td><?= htmlspecialchars($item['titulo'] ?? 'Sin título') ?></td>
                                <td>
                                    <span class="badge bg-info text-dark">
                                        <?= strtoupper($item['type'] ?? 'unknown') ?>
                                    </span>
                                </td>
                                <td><?= $item['year'] ?? '—' ?></td>
                                <td><?= substr($item['updated_at'] ?? '', 0, 10) ?></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="card-footer text-center small text-muted">
                Repositorio: <strong><?= htmlspecialchars($github_config['repo_owner'].'/'.$github_config['repo_name']) ?></strong> 
                | Rama: <strong><?= htmlspecialchars($branch) ?></strong>
            </div>
        </div>
    </div>

    <!-- Botón Scroll Top -->
    <button class="scroll-top" id="scrollTop">
        <i class="fas fa-arrow-up"></i>
    </button>

    <script>
        // Scroll to top
        window.addEventListener('scroll', () => {
            document.getElementById('scrollTop').classList.toggle('show', window.scrollY > 500);
        });
        document.getElementById('scrollTop').addEventListener('click', () => {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    </script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>